For executing web client -

   1. Create a folder "phpclient" under apache htdocs folder
   2. Unzip the attached zip file to the above "phpclient" folder
   3. Open browser and navigate to following url -
      http://localhost/phpclient/webclient.php

For executing command line client -

   1. Create a folder "phpclient" on the test machine
   2. Unzip the attached zip file to the above "phpclient" folder
   3. Open command prompt and change working directory to "phpclient" folder
   4. Execute following command to see usage instructions -
                [Path to php.exe]/php cmdclient.php -h

      An example usage -
                [Path to php.exe]/php cmdclient.php -k consumer_key -s consumer_secret -u http://thor.brightcloud.com/rest/uris/www.google.com
