  @package 	Paypal Express Checkout Sample files
  
  @license	http://opensource.org/licenses/MIT
  
  @URL		http://www.sanwebe.com/2012/07/paypal-expresscheckout-with-php

## Features

 - Checkout multiple products at once
 - Custom paypal template (logo, color...)

## Last changes

  - Checkout multiple products at once
  - Process simplified
  - Class improved
  - Functions to compute total amounts, tax and charges
  - Constants defined outside
  - Tested live and it works
