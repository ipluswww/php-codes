<?php
/**
 * Best Buy SDK
 *
 * High level PHP client for the Best Buy API
 */

namespace BestBuy\Tests;

error_reporting(E_ALL | E_STRICT);

require_once __DIR__ . '/../vendor/autoload.php';