<?php

namespace Omniphx\Forrest\Exceptions;

class MissingKeyException extends \RuntimeException
{
}
