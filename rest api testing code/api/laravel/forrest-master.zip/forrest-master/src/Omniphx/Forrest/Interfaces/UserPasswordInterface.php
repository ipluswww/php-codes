<?php

namespace Omniphx\Forrest\Interfaces;

interface UserPasswordInterface extends AuthenticationInterface
{
}
