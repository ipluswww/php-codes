<?php

namespace Omniphx\Forrest\Exceptions;

class InvalidLoginCreditialsException extends \RuntimeException
{
}
