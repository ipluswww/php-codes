<?php

namespace Omniphx\Forrest\Exceptions;

class MissingTokenException extends \RuntimeException
{
}
