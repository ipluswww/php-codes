<?php

namespace Omniphx\Forrest\Exceptions;

class MissingRefreshTokenException extends \RuntimeException
{
}
