# Changelog

All Notable changes for the Laravel 5 WooCommerce REST API Client  will be documented in this file

## 1.0.1
- Small fixes in documentation
- Added support for "verify_ssl" config option

  Add `'WOOCOMMERCE_VERIFY_SSL', false` to your `.env` file and re-publish the configuration to have this change reflected in `config/woocommerce.php`.

## 1.0.0
- Stable first release
