# RFC for version 2.0

This document should collect all topics which are relevant for version 2.0

## Todo
- drop soap support (the soap request will be provided as separate package)
- use a dedicated rest client as vendor
- drop object to array response transformer
- update API version from 2011-08-01 to 2013-08-01

## RFC
Nothing so far.
