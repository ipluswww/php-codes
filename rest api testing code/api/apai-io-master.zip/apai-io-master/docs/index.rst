Apai-IO
=======

Amazon-Product-Adverstising-API library based on PHP using REST and SOAP.
-------------------------------------------------------------------------

Contents:

.. toctree::
   chapters/installation
   chapters/basic-usage
   chapters/advanced-configuration
   chapters/built-in-operations
   chapters/custom-operations
   chapters/responsetransformer
   chapters/testing